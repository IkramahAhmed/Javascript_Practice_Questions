// practice 01 

// message = alert ("Error! please enter a valid password");

// practice 02


// message = alert ("welcome to js land! \n happy coding! \n");

// practice 03 

// var firstMessage = alert ("welcome to js land!");
// var secondMessage = alert( " Happy coding! \n prevent this page from creating additional dialog.")


// practice 04

// let message =("hellow, i can run js through my web brower console");
// console.log(message);


