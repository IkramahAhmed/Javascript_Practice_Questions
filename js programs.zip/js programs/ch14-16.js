// 1. Declare an empty array using JS literal notation to store
// student names in future.
// 2. Declare an empty array using JS object notation to store
// student names in future.
// 3. Declare and initialize a strings array.
// 4. Declare and initialize a numbers array.
// 5. Declare and initialize a boolean array.
// 6. Declare and initialize a mixed array.
// 7. Declare and Initialize an array and store available 
// education qualifications in Pakistan (e.g. SSC, HSC, BCS, 
// BS, BCOM, MS, M. Phil., PhD). Show the listed 
// qualifications in your browser like


var arr=[" "];
var arr2={" ":" "," ":" "};
var arr3=["ss"];
var arr4=["1,3,4"];
var arr5=(20>9);
var arr6=["ali","1","akli",4];
var arr7=["SSC","HSC","BCS","BS","MSC","BCOM","PHD"];


for (var i = 0; i < arr.length; i++){
    console.log(arr[i]);
   }
   for (var i = 0; i < arr2.length; i++){
    console.log(arr2[i]);
   }
   for (var i = 0; i < arr3.length; i++){
    console.log(arr3[i]);
   }

for (var i = 0; i < arr4.length; i++){
    console.log(arr4[i]);
   }

for (var i = 0; i < arr6.length; i++){
    console.log(arr6[i]);
   }

   console.log("Qualification:");
for (var i = 0; i < arr7.length; i++){
 console.log(arr7[i]);
}

