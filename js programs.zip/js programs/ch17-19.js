
// 4. Write a program to print multiplication table of any
// number using for loop. Table number & length should be
// taken as an input from user.


// var a = prompt("enter the number to show its multiplication");
// var b = prompt("enter the length");


// for(i=1;i<=b;i++){
//     console.log(a +"x",i+"=",a*i);
  
// }
//  console.log(b)

//  var fruits = ["apple","banana", "mango","orange","strawberry"];
// for (var i = 0; i < fruits.length; i++){
//     console.log("Element at index " + i + fruits[i]);
// }
//  var a= ["cake", "apple pie", "cookie", "chips", "patties"];
//  var b =prompt("welcome to my bakery sir what do you want");


// for(i=0;i<a.length;i++){
//     if(a[i] == b){
//        alert ("found at index", +i);
//     }
// else
// alert("not found");

// }

// 1. Declare and initialize an empty multidimensional array.
// (Array of arrays)
// 2. Declare and initialize a multidimensional array
// representing the following matrix:    
       
//  }


// arr=[
//     [0,1,2,3],
//     [1,0,1,2],
//     [2,1,0,1]
// ];
// for(i=0; i<arr.length; i++){
// console.log(arr[i]);
// }

// 3. Write a program to print numeric counting from 1 to 10.
// for(var i=1;i<10;i++){
//  console.log(i);  
// }

// 6. Generate the following series in your browser. See
// example output.
//counting
// for(var i=1;i<15;i++){
//       console.log(i);  
//      }


//reverse counting

// for(var i=10;i>0;i--){
//       console.log(i);  
//      }

// //EVEN NUMBER

// for(var i=0;i<12;i++){
//     if(i%2==0){
//     console.log(i);  
// }
//    }

// //ODD NUMBER

// for(var i=0;i<20;i++){
//     if(i%2==1){
//     console.log(i);  
// }
//    }

//Series
// var a = [2,4,6,8,10,12,14,16,18,20];
// var b = ["k"];

// for (var i = 0; i < a.length; i++){
   
//   for   (var j = 0; j <b.length; j++ ){
//     console.log (a[i]+ b[j]);
//   }
//     }

// 7. You have an array
// A = [“cake”, “apple pie”, “cookie”, “chips”, “patties”]
// Write a program to enable “search by user input” in an
// array.
// After searching, prompt the user whether the given item is
// found in the list or not. Example:
//     var a= ["cake", "apple pie", "cookie", "chips", "patties"];

// var userValue = prompt ("enter city name");

//  for (var i=0;i < a.length; i++){
//     if(a[i] == userValue){
//         alert("found at index" + i);
        
//          }
        
//            alert( "not found");
//            break;
          
       
//         }

// Write a program to identify the Largest number in the
// given array.
        // var arr = [120,24, 105,78, 106, 12,110];
// var max=0;
// for(i=0;i<arr.length;i++){

// if(max < arr[i]){

//     max=arr[i];
    
// }
// }
// console.log("the larget number is", + max);


// Write a program to identify the smallest number in the
// given array.

//         var arr = [120,24, 105,78, 106, 12,110];
// var max=arr[0];
// for(i=0;i<arr.length;i++){

// if(max > arr[i]){

//     max=arr[i];
    
// }
// }
// console.log("the Smallest number is", + max);


// 10. Write a program to print multiples of 5 ranging 1 to
// 100.

// for(var i=5;i<105;i++){
//     if(i%5==0){
//     console.log(i);  
// }
//    }
