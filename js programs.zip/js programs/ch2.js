// practice 01 

// let username =("eman villani");
// console.log(username);

// practice 02

// let myName = "muhammad eman villani sohail";
// console.log (myName);

// let message = "hellow world";
// alert (message);

// practice 03

// let studentName = "eman villani";
// let age = "15 years";
// let profession = "mobile application developer";
// alert (studentName,age,profession); 
// alert (age); 
// alert(profession);

// practice 04

// let name = "pizza \n pizz \n piz \n pi \n p";
// alert(name);

// practice 05

// let email = "my email address" + " is emanvillani@.com"
// alert (email);

// practice 06

// let book = "i'm trying to learn from the book smarter way to learn javascript";
// alert(book);

// practice 07

// let text = "yah! i can write html content through javascript ";
// document.write (text);

// practice 08

// let end = "=============ஜ۩۞۩ஜ============ ";
// alert (end);


