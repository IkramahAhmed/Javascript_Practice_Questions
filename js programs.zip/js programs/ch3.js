// practice 01 
// let age = "15 years old";
// alert (age);

// practice 02
// let visits = "you have visited the website 14 times";
// alert (visits);

// practice 03
// let birthYear = "my year of birth is 2000";
// document.write (birthYear);

// practice 05
let name = "ali";
let producttitle = "computer";
let quantity = "01";

document.write(name+ " ordered "+ + quantity + " "+  producttitle + " from computer zone")


